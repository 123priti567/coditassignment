﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ParkingManagement
{
    public class Display
    {
        public void showVehicleType(ArrayList a1)
        {
            foreach (Object o in a1)
                Console.WriteLine(o);
        }
        public Boolean displayAvailableSlots(ArrayList a1, ArrayList a2, ArrayList a3)
        {
            Console.WriteLine("Below is the list of avaialbe slots for each vehicle type \n\n\n");
            
            Console.WriteLine("Hatchback :");
            foreach (int s in a1)
            Console.Write(" " + s);

            Console.WriteLine();

            Console.WriteLine("Sedan :");
            foreach (int s in a2)
                Console.Write(" "+s);

            Console.WriteLine();

            Console.WriteLine("SUV :");
            foreach (int s in a3)
                Console.Write(" "+s);

            return true;
        }

        public Boolean displayAllocatedSlots(ArrayList a1, ArrayList a2, ArrayList a3)
        {
            Console.WriteLine("Below is the list of avaialbe slots for each vehicle type \n\n\n");

            Console.WriteLine("Hatchback :");
            foreach (int s in a1)
                Console.Write(" "+s);

            Console.WriteLine();

            Console.WriteLine("Sedan :");
            foreach (int s in a2)
                Console.Write(" "+s);

            Console.WriteLine();

            Console.WriteLine("SUV :");
            foreach (int s in a3)
                Console.Write(" "+s);

            return true;
        }
    }
}
