﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ParkingManagement
{
    class Vehicle
    {

        public Vehicle(ArrayList a1, ArrayList a2)
        {
            a1.Add("Hatchback");
            a2.Add(50);

            a1.Add("Sedan");
            a2.Add(30);

            a1.Add("SUV");
            a2.Add(20);
        }
        public void addVehicleType(ArrayList a1, string v, int x)
        {
            a1.Add(v);
            a1.Add(x);
            Console.WriteLine("Vehicle type and corresponding slots are added successfully!");
        }

       }
}
