﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingManagement
{
    class Program
    {
        static ParkManager manager = new ParkManager();
        static void Main(string[] args)
        {

            Parking carParking = new Parking();
            manager.ShowMenu();
        }
    }
}
