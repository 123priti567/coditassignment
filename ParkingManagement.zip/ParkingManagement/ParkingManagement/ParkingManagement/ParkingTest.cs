﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingManagement
{
    [TestFixture]
    class ParkingTest
    {
        [TestCase]
        public void AddCarTestH1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(1, park.AddCar(pm.availableSlotsH, pm.allocatedSlotsH));
           
        }

        [TestCase]
        public void AddCarTestS1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(1, park.AddCar(pm.availableSlotsS, pm.allocatedSlotsS));

        }

        [TestCase]
        public void AddCarTestL1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(1, park.AddCar(pm.availableSlotsL, pm.allocatedSlotsL));

        }


        [TestCase]
        public void RemoveCarTestH1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(true, park.RemoveCar(pm.availableSlotsH,pm.allocatedSlotsH,1));
        }

        [TestCase]
        public void RemoveCarTestS1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(true, park.RemoveCar(pm.availableSlotsS, pm.allocatedSlotsS, 1));

        }

        [TestCase]
        public void RemoveCarTestL1()
        {
            Parking park = new Parking();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(true, park.RemoveCar(pm.availableSlotsL, pm.allocatedSlotsL, 1));
        }

        [TestCase]
        public void dispAvailSlotTest()
        {
            Display ds = new Display();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(true, ds.displayAvailableSlots(pm.availableSlotsH, pm.availableSlotsS, pm.availableSlotsL));
        }

        public void dispAllocatedSlotTest()
        {
            Display ds = new Display();
            ParkManager pm = new ParkManager();
            Assert.AreEqual(true, ds.displayAllocatedSlots(pm.allocatedSlotsH, pm.allocatedSlotsS, pm.allocatedSlotsL));
        }

    }
}
