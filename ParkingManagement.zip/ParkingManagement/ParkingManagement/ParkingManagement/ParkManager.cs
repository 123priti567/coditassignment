﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using NUnit.Framework;

namespace ParkingManagement
{
   
    public class ParkManager
    {
        private string greeting = "\t\tWelcome To Car Parking Management System!\n\n\n";
        private string menuItems = " Choose the task below :\n\n Press \"A\" - TO PARK VEHICLE\n Press \"B\" - TO REMOVE VEHICLE \n Press \"C\" - TO SHOW AVAILABLE VEHICLETYPES \n Press \"D\" - TO DISPLAY AVAILABLE SLOTS \n Press \"E\" - TO DISPLAY ALLOCATED SLOTS \n Press \"Esc\" - TO EXIT";
        Parking CarParking = new Parking();
        
        static ArrayList vehicleType = new ArrayList();
        static ArrayList vehicleSlots = new ArrayList();
        Vehicle Veh = new Vehicle(vehicleType,vehicleSlots);

        Display dis = new Display();

        int totalSlotsH = 50, totalSlotsS = 30, totalSlotsL = 20;
        public ArrayList availableSlotsH = new ArrayList();
        public ArrayList availableSlotsS = new ArrayList();
        public ArrayList availableSlotsL = new ArrayList();
        public ArrayList allocatedSlotsH = new ArrayList();
        public ArrayList allocatedSlotsS = new ArrayList();
        public ArrayList allocatedSlotsL = new ArrayList();

        public ParkManager()
        {
            for (int i = 1; i <= totalSlotsH; i++)
                availableSlotsH.Add(i);

            for (int i = 1; i <= totalSlotsS; i++)
                availableSlotsS.Add(i);

            for (int i = 1; i <= totalSlotsL; i++)
                availableSlotsL.Add(i);
        }
        
        public void ShowMenu()
        {
            do
            {
                Console.Clear();
                Console.WriteLine(greeting);
                Console.WriteLine(menuItems);
                ConsoleKey pressedKey = Console.ReadKey().Key;
               
                
                switch (pressedKey)
                {
                    case ConsoleKey.A:
                        Console.Clear();
                        ShowAddMenu();
                        Console.ReadKey();
                        break;

                    case ConsoleKey.B:
                        Console.Clear();
                        RemoveCar();
                        Console.ReadKey();
                        break;

                    case ConsoleKey.C:
                        Console.Clear();
                        dis.showVehicleType(vehicleType);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.D:
                        Console.Clear();
                        Boolean y=dis.displayAvailableSlots(availableSlotsH,availableSlotsS,availableSlotsL);
                        Console.ReadKey();
                        break;

                    case ConsoleKey.E:
                        Console.Clear();
                        Boolean z = dis.displayAllocatedSlots(allocatedSlotsH, allocatedSlotsS, allocatedSlotsL);
                        Console.ReadKey();
                        break;


                    case ConsoleKey.Escape:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Option!!!");
                        break;
                }
            } while (true);
        }


        private void ShowAddMenu()
        {


            Console.Clear();
            Console.WriteLine("Choose the Vehicle Type:\n\n\n Press \"H\" - FOR HATCHBACK \n Press \"S\" - FOR SEDAN or COMPACT SUV \n Press \"L\" - FOR LARGE or SUV");
            ConsoleKey pressedKey = Console.ReadKey().Key;
            
            //Car newCar;
            switch (pressedKey)
            {
                
                case ConsoleKey.H:
                    CarParking = new Parking();
                    int tkth, tkts, tktl;
                    tkth = CarParking.AddCar(availableSlotsH, allocatedSlotsH);
                    if (tkth > 0)
                    { Console.WriteLine("\nYour Allocated parking slot is H" + tkth); }
                    else
                    {
                        tkts = CarParking.AddCar(availableSlotsS, allocatedSlotsS);
                        if (tkts > 0)
                            Console.WriteLine("\nYour Allocated parking slot is S" + tkts);
                        else
                        {
                            tktl = CarParking.AddCar(availableSlotsL, allocatedSlotsL);
                            if (tktl > 0)
                                Console.WriteLine("\nYour Allocated parking slot is L" + tktl);
                            else
                                Console.WriteLine("\nParking Full !");
                        }
                    }
                                         
                    return;


                case ConsoleKey.S:

                    tkts = CarParking.AddCar(availableSlotsS, allocatedSlotsS);
                    if (tkts > 0)
                        Console.WriteLine("\nYour Allocated parking slot is S" + tkts);
                    else
                    {
                        tktl = CarParking.AddCar(availableSlotsL, allocatedSlotsL);
                        if (tktl > 0)
                            Console.WriteLine("\nYour Allocated parking slot is L" + tktl);
                        else
                            Console.WriteLine("\nParking Full !");
                    }
                    return;

                case ConsoleKey.L:
                     tktl = CarParking.AddCar(availableSlotsL, allocatedSlotsL);
                    if (tktl > 0)
                        Console.WriteLine("\nYour Allocated parking slot is L" + tktl);
                    else
                        Console.WriteLine("\nParking Full !");
                    return;

                default:
                    break;
            }

        }         
                    

        private void RemoveCar()
        {

            Console.Clear();
            Console.WriteLine("Choose the Exit Car Type:\n\n\n Press \"H\" - FOR HATCHBACK \n Press \"S\" - FOR SEDAN or COMPACT SUV \n Press \"L\" - FOR LARGE or SUV");
            Console.WriteLine();
            int tkt=0;
            ConsoleKey pressedKey = Console.ReadKey().Key;
            //Car newCar;
            switch (pressedKey)
            {
                 case ConsoleKey.H:
                    Console.WriteLine("\nEnter the parking tkt number");
                    tkt = Convert.ToInt32(Console.ReadLine());
                    if (CarParking.chktkt(allocatedSlotsH, tkt))
                    {
                        Boolean b=CarParking.RemoveCar(availableSlotsH, allocatedSlotsH, tkt);
                        if (b==true)
                            Console.WriteLine("Car Exit Successfull!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid ticket number");
                        Console.ReadKey();
                        RemoveCar();
                    }
                    return;

                case ConsoleKey.S:
                    Console.WriteLine("\nEnter the parking tkt number");
                    tkt = Convert.ToInt32(Console.ReadLine());
                    if (CarParking.chktkt(allocatedSlotsS, tkt))
                    {
                        CarParking.RemoveCar(availableSlotsS, allocatedSlotsS, tkt);
                        Console.WriteLine("Car Exit Successfull!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid ticket number");
                        Console.ReadKey();
                        RemoveCar();
                    }
                    return;

                case ConsoleKey.L:
                    Console.WriteLine("\nEnter the parking tkt number");
                    tkt = Convert.ToInt32(Console.ReadLine());
                    if (CarParking.chktkt(allocatedSlotsL, tkt))
                    {
                        CarParking.RemoveCar(availableSlotsL, allocatedSlotsL, tkt);
                        Console.WriteLine("Car Exit Successfull!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid ticket number");
                        Console.ReadKey();
                        RemoveCar();
                    }
                    return;
            }

        }

        private void addVehicleType()
        {
            Console.WriteLine("\n Enter the type of vehicke you want to add");
            string vtype = Console.ReadLine();
            Console.WriteLine("\n Enter the number of parking slots");
            int n = Convert.ToInt32(Console.ReadLine());

            Veh.addVehicleType(vehicleType,vtype,n);

        }

    }

}

