﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ParkingManagement
{
        class Parking 
        {
 
        public int AddCar(ArrayList a1, ArrayList a2)
        {
            int tkt = 0;
            if (a1.Count > 0)
            { tkt = Convert.ToInt32(a1[0]);
                a2.Add(tkt);
                a1.RemoveAt(0);
            }
                return tkt;
        }

        public Boolean chktkt(ArrayList a1, int x)
        {
            
            if (a1.Contains(x))
                return true;
            else
                return false;
        }

        public Boolean RemoveCar(ArrayList a1, ArrayList a2, int x)
        {
            a1.Add(x);
            a2.Remove(x);
            return true;
        }   
        }
}
